"""
Package for Common Things
"""

from . import status_codes
