# Backend of SPA E-Commerce Pokemon Shop
TODO: Provide Explanation about backend