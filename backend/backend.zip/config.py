"""
Global Configuration for Flask application
"""
